package com.petmorph.ai.data.local

import androidx.room.*
import com.petmorph.ai.data.model.CompanionEntity
import com.petmorph.ai.data.model.ChatMessageEntity
import com.petmorph.ai.data.model.ReminderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanionDao {
    @Query("SELECT * FROM companions ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<CompanionEntity>>

    @Query("SELECT * FROM companions WHERE id = :id")
    fun observeById(id: String): Flow<CompanionEntity?>

    @Query("SELECT * FROM companions WHERE id = :id")
    suspend fun getById(id: String): CompanionEntity?

    @Query("SELECT COUNT(*) FROM companions")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: CompanionEntity)

    @Update
    suspend fun update(entity: CompanionEntity)

    @Delete
    suspend fun delete(entity: CompanionEntity)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages WHERE companionId = :id ORDER BY timestamp ASC")
    fun observeFor(id: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE companionId = :id ORDER BY timestamp DESC LIMIT :limit")
    suspend fun recentFor(id: String, limit: Int): List<ChatMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(msg: ChatMessageEntity)

    @Query("DELETE FROM chat_messages WHERE companionId = :id")
    suspend fun clearFor(id: String)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders WHERE companionId = :id")
    fun observeFor(id: String): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun getReminderById(id: String): ReminderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(r: ReminderEntity)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun delete(id: String)
}
