package com.petmorph.ai.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.petmorph.ai.PetMorphApp
import com.petmorph.ai.ai.ChatContext
import com.petmorph.ai.ai.ChatResult
import com.petmorph.ai.core.AppContainer
import com.petmorph.ai.data.model.*
import com.petmorph.ai.domain.Gamification
import com.petmorph.ai.image.ProcessResult
import com.petmorph.ai.reminder.ReminderScheduler
import com.petmorph.ai.tts.BackendVoiceCloneProvider
import com.petmorph.ai.tts.VoiceCloneResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed class ProcessingState {
    data object Idle : ProcessingState()
    data object Loading : ProcessingState()
    data class Success(val companionId: String) : ProcessingState()
    data class Error(val message: String) : ProcessingState()
}

sealed class VoiceCloneState {
    data object Idle : VoiceCloneState()
    data object Uploading : VoiceCloneState()
    data class Done(val voiceId: String) : VoiceCloneState()
    data class Failed(val message: String) : VoiceCloneState()
}

class CompanionViewModel(app: Application) : AndroidViewModel(app) {
    val container: AppContainer = (app as PetMorphApp).container
    private val app get() = getApplication<PetMorphApp>()

    val companions: StateFlow<List<CompanionEntity>> =
        container.repository.observeCompanions()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val processing = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val talking = MutableStateFlow(false)
    val voiceClone = MutableStateFlow<VoiceCloneState>(VoiceCloneState.Idle)

    private val voiceCloner = BackendVoiceCloneProvider(container.api)
    private var mediaPlayer: MediaPlayer? = null

    init {
        viewModelScope.launch { container.repository.seedDemoIfNeeded(container.storage) }
    }

    fun observeCompanion(id: String): Flow<CompanionEntity?> = container.repository.observeCompanion(id)
    fun observeChat(id: String) = container.database.chatDao().observeFor(id)
    fun observeReminders(id: String) = container.database.reminderDao().observeFor(id)

    // ---------- pembuatan ----------
    fun createFromImage(uri: Uri, name: String, type: CompanionType, personality: Personality) {
        viewModelScope.launch {
            processing.value = ProcessingState.Loading
            try {
                val id = withContext(Dispatchers.IO) {
                    val original = copyUriToInternal(uri, "original_${System.currentTimeMillis()}.png")
                    val src = BitmapFactory.decodeFile(original)
                        ?: throw IllegalStateException("Could not decode image")
                    if (src.width * src.height > 4000 * 4000) throw IllegalStateException("Image too large")
                    val noBg = when (val r = container.imageProcessor.removeBackground(src)) {
                        is ProcessResult.Success -> r.bitmap
                        is ProcessResult.Error -> throw IllegalStateException(r.message)
                    }
                    val normalized = container.imageProcessor.normalize(noBg)
                    val processed = container.storage.saveBitmap(normalized, "processed_${System.currentTimeMillis()}.png")
                    src.recycle()
                    val entity = CompanionEntity(
                        name = name, type = type, personality = personality,
                        originalImagePath = original, processedImagePath = processed,
                        voiceJson = CompanionEntity.voiceToJson(VoiceConfig()),
                    )
                    container.repository.save(entity)
                    com.petmorph.ai.widget.CompanionWidgetProvider.notifyChanged(app)
                    entity.id
                }
                processing.value = ProcessingState.Success(id)
            } catch (e: Exception) {
                processing.value = ProcessingState.Error(e.message ?: "Processing failed")
            }
        }
    }

    /** Buat companion langsung dari karakter bawaan. */
    fun createFromAsset(asset: Int, name: String, type: CompanionType, personality: Personality) {
        viewModelScope.launch {
            processing.value = ProcessingState.Loading
            try {
                val entity = container.repository.createFromAsset(asset, name, type, personality, container.storage)
                com.petmorph.ai.widget.CompanionWidgetProvider.notifyChanged(app)
                processing.value = ProcessingState.Success(entity.id)
            } catch (e: Exception) {
                processing.value = ProcessingState.Error(e.message ?: "Gagal memuat karakter")
            }
        }
    }

    private suspend fun copyUriToInternal(uri: Uri, fileName: String): String =
        withContext(Dispatchers.IO) {
            val input = app.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Cannot read selected image")
            val file = File(app.filesDir, fileName)
            input.use { i -> file.outputStream().use { o -> i.copyTo(o) } }
            file.absolutePath
        }

    fun loadBitmap(path: String): Bitmap? = runCatching { BitmapFactory.decodeFile(path) }.getOrNull()

    fun loadBitmapFromResource(resId: Int): Bitmap? =
        runCatching { BitmapFactory.decodeResource(app.resources, resId) }.getOrNull()

    // ---------- CRUD ----------
    fun updateCompanion(entity: CompanionEntity) = viewModelScope.launch {
        container.repository.update(entity)
        com.petmorph.ai.widget.CompanionWidgetProvider.notifyChanged(app)
    }
    fun rename(id: String, newName: String) = viewModelScope.launch {
        container.repository.get(id)?.let { container.repository.update(it.copy(name = newName)) }
    }
    fun duplicate(id: String) = viewModelScope.launch { container.repository.duplicate(id) }
    fun delete(id: String) = viewModelScope.launch { container.repository.delete(id) }

    // ---------- gamifikasi ----------
    private suspend fun applyAction(id: String, action: Gamification.Action) {
        container.repository.get(id)?.let { e ->
            container.repository.update(e.copy(
                xp = e.xp + action.xp,
                mood = Gamification.applyMoodTraits(
                    (e.mood + action.mood).coerceIn(Gamification.MIN_MOOD, Gamification.MAX_MOOD),
                    e.traitList()),
            ))
        }
    }
    fun onTap(id: String) = viewModelScope.launch { applyAction(id, Gamification.Action.Tap) }
    fun onTrick(id: String) = viewModelScope.launch { applyAction(id, Gamification.Action.Trick) }

    fun decayMoodAll(hours: Int = 1) = viewModelScope.launch {
        companions.value.forEach { e ->
            container.repository.update(e.copy(
                mood = (e.mood - Gamification.moodDecayPerHour(e.traitList()) * hours)
                    .coerceIn(Gamification.MIN_MOOD, Gamification.MAX_MOOD)))
        }
    }

    // ---------- chat kontekstual ----------
    fun chat(entity: CompanionEntity, message: String) {
        viewModelScope.launch {
            val dao = container.database.chatDao()
            dao.insert(ChatMessageEntity(companionId = entity.id, fromUser = true, text = message))
            applyAction(entity.id, Gamification.Action.Chat)

            val recent = dao.recentFor(entity.id, 10).reversed().map { (it.fromUser to it.text) }
            val ctx = ChatContext(history = recent, mood = entity.mood,
                level = Gamification.levelFor(entity.xp), traits = entity.traitList())

            when (val result = container.ai.chat(entity.name, entity.personality, message, ctx)) {
                is ChatResult.Success -> {
                    dao.insert(ChatMessageEntity(companionId = entity.id, fromUser = false,
                        text = result.reply, fromCloud = result.fromCloud))
                    speak(entity, result.reply)
                }
                is ChatResult.Error ->
                    container.sounds.play(com.petmorph.ai.audio.SoundEffect.ERROR)
            }
        }
    }

    // ---------- suara ----------
    fun speak(entity: CompanionEntity, text: String) {
        val v = entity.voice()
        if (v.muted) return
        viewModelScope.launch {
            if (entity.voiceId.isNotBlank() && playCloudTts(entity.voiceId, text, v.volume)) return@launch
            try {
                talking.value = true
                container.tts.setOnDoneListener { talking.value = false }
                container.tts.speak(text, v.rate, v.pitch, v.volume)
            } catch (e: Exception) { talking.value = false }
        }
    }

    private suspend fun playCloudTts(voiceId: String, text: String, volume: Float): Boolean =
        withContext(Dispatchers.IO) {
            runCatching {
                val res = container.api.api.tts(com.petmorph.ai.network.TtsRequest(text, voiceId))
                val bytes = res.body()?.audioBase64 ?: return@runCatching false
                val file = File.createTempFile("tts", ".wav", app.cacheDir)
                file.writeBytes(android.util.Base64.decode(bytes, android.util.Base64.DEFAULT))
                talking.value = true
                mediaPlayer?.release()
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    setVolume(volume, volume)
                    setOnCompletionListener { talking.value = false; runCatching { file.delete() } }
                    prepare(); start()
                }
                true
            }.getOrDefault(false)
        }

    // ---------- voice cloning (premium) ----------
    fun cloneVoice(entity: CompanionEntity, sampleUri: Uri) {
        viewModelScope.launch {
            if (!container.subscription.isPro.first()) {
                voiceClone.value = VoiceCloneState.Failed("Fitur premium — butuh langganan Pro")
                return@launch
            }
            voiceClone.value = VoiceCloneState.Uploading
            try {
                val tmp = withContext(Dispatchers.IO) {
                    val input = app.contentResolver.openInputStream(sampleUri)
                        ?: throw IllegalStateException("Tidak bisa membaca file suara")
                    val f = File.createTempFile("voice_sample", ".m4a", app.cacheDir)
                    input.use { it.copyTo(f.outputStream()) }
                    f
                }
                when (val r = voiceCloner.cloneSample(tmp)) {
                    is VoiceCloneResult.Success -> {
                        container.repository.update(entity.copy(voiceId = r.voiceId))
                        voiceClone.value = VoiceCloneState.Done(r.voiceId)
                        applyAction(entity.id, Gamification.Action.VoiceChat)
                    }
                    is VoiceCloneResult.Error -> voiceClone.value = VoiceCloneState.Failed(r.message)
                }
                tmp.delete()
            } catch (e: Exception) {
                voiceClone.value = VoiceCloneState.Failed(e.message ?: "Upload gagal")
            }
        }
    }

    // ---------- pengingat ----------
    fun addReminder(companionId: String, hour: Int, minute: Int, message: String) =
        viewModelScope.launch {
            val r = ReminderEntity(companionId = companionId, hour = hour, minute = minute, message = message)
            container.database.reminderDao().upsert(r)
            ReminderScheduler.schedule(app, r)
        }

    fun removeReminder(reminder: ReminderEntity) = viewModelScope.launch {
        container.database.reminderDao().delete(reminder.id)
        ReminderScheduler.cancel(app, reminder.id)
    }

    fun setTalkState(t: Boolean) { talking.value = t }

    override fun onCleared() {
        container.tts.stop()
        mediaPlayer?.release()
        super.onCleared()
    }
}
