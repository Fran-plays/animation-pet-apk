package com.petmorph.ai.animation

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

data class MeshChannels(
    val headDx: Float = 0f, val headDy: Float = 0f,
    val bodySquash: Float = 0f, val tilt: Float = 0f,
    val bob: Float = 0f, val wave: Float = 0f, val wobble: Float = 0f,
)

/** Engine deformasi mesh: grid N x N; tiap vertex digeser berbobot dari anchor
 *  kepala/badan — bitmap benar-benar melengkung. Pure Kotlin, dapat diuji JVM. */
class MeshWarpEngine(val gridN: Int = 14) {

    fun vertexCount(): Int = gridN * gridN

    fun computeWarp(
        anchors: RigAnchors, ch: MeshChannels,
        outX: FloatArray, outY: FloatArray,
        texU: FloatArray, texV: FloatArray,
        w: Float, h: Float,
    ) {
        val fallHead = 0.30f * w
        val fallBody = 0.42f * w
        val bobPx = ch.bob * 0.10f * h
        val headPxX = anchors.headX * w
        val headPxY = anchors.headY * h
        val bodyPxX = anchors.bodyX * w
        val bodyPxY = anchors.bodyY * h

        for (i in 0 until gridN * gridN) {
            val bx = texU[i]; val by = texV[i]
            var dx = 0f; var dy = bobPx

            val dh = kotlin.math.hypot((bx - headPxX).toDouble(), (by - headPxY).toDouble()).toFloat()
            val wh = 1f / (1f + (dh / fallHead).pow(2))
            dx += ch.headDx * 0.25f * w * wh
            dy += ch.headDy * 0.15f * h * wh

            val angle = ch.tilt * 0.22f
            if (angle != 0f) {
                val rx = bx - bodyPxX; val ry = by - bodyPxY
                dx += (rx * cos(angle) - ry * sin(angle) - rx) * 0.6f
                dy += (rx * sin(angle) + ry * cos(angle) - ry) * 0.6f
            }

            val db = kotlin.math.hypot((bx - bodyPxX).toDouble(), (by - bodyPxY).toDouble()).toFloat()
            val wBody = 1f / (1f + (db / fallBody).pow(2))
            val sx = 1f + ch.bodySquash * 0.18f * wBody
            val sy = 1f - ch.bodySquash * 0.22f * wBody
            dx += (bx - bodyPxX) * (sx - 1f) * 0.9f
            dy += (by - bodyPxY) * (sy - 1f) * 0.9f

            if (ch.wave > 0.001f) {
                val depth = (by / h).coerceIn(0f, 1f)
                dx += sin(depth * PI.toFloat() * 2f) * ch.wave * 0.12f * w * depth
            }
            if (ch.wobble > 0.001f) {
                dx += sin(bx * 0.35f + by * 0.2f) * ch.wobble * 0.02f * w
            }
            outX[i] = bx + dx
            outY[i] = by + dy
        }
    }

    fun triangleIndices(): IntArray {
        val idx = ArrayList<Int>((gridN - 1) * (gridN - 1) * 6)
        for (gy in 0 until gridN - 1) for (gx in 0 until gridN - 1) {
            val a = gy * gridN + gx; val b = a + 1; val c = a + gridN; val d = c + 1
            idx.add(a); idx.add(c); idx.add(b); idx.add(b); idx.add(c); idx.add(d)
        }
        return idx.toIntArray()
    }
}

/** Kurva channel per state sebagai fungsi fase 0..1 (satu siklus). */
object MeshCurves {
    fun channelsFor(state: AnimationState, phase: Float): MeshChannels {
        val s = sin(phase * 2f * PI.toFloat())
        val s2 = sin(phase * 4f * PI.toFloat())
        val abs = kotlin.math.abs(s)
        val abs2 = kotlin.math.abs(s2)
        return when (state) {
            AnimationState.IDLE -> MeshChannels(bodySquash = s * 0.35f, bob = s * 0.15f)
            AnimationState.HAPPY -> MeshChannels(bodySquash = abs * 0.9f, bob = abs2 * 0.5f, headDy = -abs * 0.6f)
            AnimationState.SAD -> MeshChannels(headDy = 0.7f, bodySquash = -0.25f, tilt = 0.25f, bob = s * 0.05f)
            AnimationState.ANGRY -> MeshChannels(wobble = 1f, headDx = s * 0.35f, bodySquash = s * 0.3f, tilt = s * 0.2f)
            AnimationState.SURPRISED -> MeshChannels(bodySquash = -0.6f, bob = -0.3f, wobble = 0.3f)
            AnimationState.SLEEP -> MeshChannels(bodySquash = -0.3f, headDy = 0.4f, tilt = 0.3f, bob = s * 0.3f)
            AnimationState.WAVE -> MeshChannels(headDx = s * 0.9f, wave = 0.5f, bob = abs * 0.25f)
            AnimationState.JUMP -> MeshChannels(bob = -s * 1.0f, bodySquash = -s * 0.7f)
            AnimationState.BOUNCE -> MeshChannels(bob = -abs * 0.8f, bodySquash = -s * 0.5f)
            AnimationState.DANCE -> MeshChannels(wave = 0.8f, tilt = s * 0.6f, bodySquash = s * 0.5f, headDx = s2 * 0.4f, bob = abs * 0.4f)
            AnimationState.TALK -> MeshChannels(headDx = s * 0.25f, bodySquash = s * 0.2f)
            AnimationState.EXCITED -> MeshChannels(wobble = 0.7f, bob = -abs2 * 0.9f, bodySquash = s * 0.8f, wave = 0.3f)
            AnimationState.CLICK -> MeshChannels(bodySquash = -0.9f, bob = 0.2f)
        }
    }
}
