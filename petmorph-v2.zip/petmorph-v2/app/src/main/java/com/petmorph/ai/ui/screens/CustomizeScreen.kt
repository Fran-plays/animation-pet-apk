package com.petmorph.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.petmorph.ai.data.model.*
import com.petmorph.ai.domain.Gamification
import com.petmorph.ai.ui.CompanionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomizeScreen(nav: NavController, vm: CompanionViewModel, companionId: String) {
    val entity by vm.observeCompanion(companionId).collectAsState(initial = null)
    val e = entity ?: run {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    var skin by remember(e) { mutableStateOf(e.skinEnum()) }
    var accessory by remember(e) { mutableStateOf(e.accessoryEnum()) }
    var traits by remember(e) { mutableStateOf(e.traitList()) }
    val level = Gamification.levelFor(e.xp)

    Scaffold(topBar = {
        TopAppBar(title = { Text("Kustomisasi ${e.name}") },
            navigationIcon = { IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
            .padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {

            Text("Skin tampilan", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Skin.entries.forEach { sk ->
                val locked = level < sk.minLevel
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    RadioButton(selected = skin == sk, onClick = { if (!locked) skin = sk }, enabled = !locked)
                    Text(sk.label + if (locked) "  🔒 Lv.${sk.minLevel}" else "")
                    Spacer(Modifier.weight(1f))
                    (sk.frameArgb ?: sk.tintArgb)?.let {
                        Box(Modifier.size(22.dp).clip(CircleShape)) {
                            Box(Modifier.fillMaxSize().clip(CircleShape), contentAlignment = Alignment.Center) {
                                Box(Modifier.fillMaxSize(0.8f).clip(CircleShape))
                            }
                        }
                        // indikator warna
                        Box(Modifier.size(22.dp).clip(CircleShape))
                    }
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Aksesori", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Accessory.entries.forEach { a ->
                val locked = level < a.minLevel
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = accessory == a, onClick = { if (!locked) accessory = a }, enabled = !locked)
                    Text(a.label + if (locked) "  🔒 Lv.${a.minLevel}" else "")
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Watak karakter (maks. 2)", style = MaterialTheme.typography.titleMedium)
            Text("Watak memengaruhi cara bicara, animasi idle, dan kecepatan mood berubah.",
                style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(4.dp))
            Trait.entries.forEach { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = traits.contains(t), onCheckedChange = { on ->
                        traits = when {
                            on && traits.size < 2 -> traits + t
                            on -> listOf(traits.last(), t)
                            else -> traits - t
                        }
                    })
                    Column {
                        Text(t.label)
                        Text(t.promptHint, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                vm.updateCompanion(e.copy(skin = skin.name, accessory = accessory.name,
                    traits = CompanionEntity.traitsToString(traits)))
                nav.popBackStack()
            }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("Simpan") }
            Spacer(Modifier.height(24.dp))
        }
    }
}
