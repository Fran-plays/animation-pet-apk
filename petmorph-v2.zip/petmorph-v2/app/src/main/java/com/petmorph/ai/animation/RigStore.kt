package com.petmorph.ai.animation

import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Auto-rig sekali per bitmap, hasil di-cache. */
object RigStore {
    private val cache = HashMap<Int, RigAnchors>()

    suspend fun anchorsFor(bitmap: Bitmap): RigAnchors = withContext(Dispatchers.Default) {
        val key = System.identityHashCode(bitmap)
        synchronized(cache) { cache[key] }?.let { return@withContext it }
        val px = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(px, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        AutoRigger().rig(bitmap.width, bitmap.height, px).also {
            synchronized(cache) {
                if (cache.size > 16) cache.clear()
                cache[key] = it
            }
        }
    }
}
