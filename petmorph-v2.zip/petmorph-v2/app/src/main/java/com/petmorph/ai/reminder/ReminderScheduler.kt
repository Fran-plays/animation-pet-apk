package com.petmorph.ai.reminder

import android.content.Context
import androidx.work.*
import com.petmorph.ai.PetMorphApp
import com.petmorph.ai.data.model.ReminderEntity
import java.util.Calendar
import java.util.concurrent.TimeUnit

class ReminderWorker(context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val reminderId = inputData.getString(KEY_ID) ?: return Result.failure()
        val app = applicationContext as PetMorphApp
        val reminder = app.container.database.reminderDao().getReminderById(reminderId)
            ?: return Result.success()
        if (!reminder.enabled) return Result.success()

        val companion = app.container.repository.get(reminder.companionId)
        NotificationHelper.showReminder(
            applicationContext,
            companion?.name ?: "Companion",
            reminder.message,
            companion?.processedImagePath,
        )
        ReminderScheduler.schedule(applicationContext, reminder)
        return Result.success()
    }

    companion object { const val KEY_ID = "reminder_id" }
}

object ReminderScheduler {
    fun schedule(context: Context, reminder: ReminderEntity) {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, reminder.hour)
            set(Calendar.MINUTE, reminder.minute)
            set(Calendar.SECOND, 0)
            if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        val data = Data.Builder().putString(ReminderWorker.KEY_ID, reminder.id).build()
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(target.timeInMillis - now.timeInMillis, TimeUnit.MILLISECONDS)
            .setInputData(data)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            tagFor(reminder.id), ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel(context: Context, reminderId: String) {
        WorkManager.getInstance(context).cancelUniqueWork(tagFor(reminderId))
    }

    private fun tagFor(id: String) = "reminder_$id"
}
