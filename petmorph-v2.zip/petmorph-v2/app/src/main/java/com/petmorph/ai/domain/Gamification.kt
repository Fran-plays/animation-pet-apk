package com.petmorph.ai.domain

import com.petmorph.ai.animation.AnimationState
import com.petmorph.ai.data.model.Trait

/** Aturan gamifikasi — pure Kotlin agar mudah diuji. */
object Gamification {
    const val XP_PER_LEVEL = 100
    const val MAX_MOOD = 100
    const val MIN_MOOD = 0

    fun levelFor(xp: Int): Int = xp / XP_PER_LEVEL + 1
    fun xpProgress(xp: Int): Float = (xp % XP_PER_LEVEL) / XP_PER_LEVEL.toFloat()

    sealed class Action(val xp: Int, val mood: Int) {
        data object Chat : Action(5, +3)
        data object Tap : Action(1, +1)
        data object Trick : Action(4, +2)
        data object VoiceChat : Action(8, +3)
    }

    fun moodDecayPerHour(traits: List<Trait>): Int = when {
        traits.contains(Trait.LOYAL) -> 3
        traits.contains(Trait.SLEEPY) -> 1
        else -> 2
    }

    fun applyMoodTraits(base: Int, traits: List<Trait>): Int = when {
        traits.contains(Trait.GRUMPY) -> (base - 5).coerceIn(MIN_MOOD, MAX_MOOD)
        traits.contains(Trait.PLAYFUL) -> (base + 3).coerceIn(MIN_MOOD, MAX_MOOD)
        else -> base
    }

    fun idleBias(mood: Int, traits: List<Trait>): AnimationState = when {
        mood < 30 -> AnimationState.SAD
        traits.contains(Trait.SLEEPY) && mood in 30..55 -> AnimationState.SLEEP
        traits.contains(Trait.PLAYFUL) && mood > 75 -> AnimationState.BOUNCE
        mood > 85 -> AnimationState.EXCITED
        else -> AnimationState.IDLE
    }

    fun moodLabel(mood: Int): String = when {
        mood >= 80 -> "Sangat bahagia"
        mood >= 60 -> "Bahagia"
        mood >= 40 -> "Biasa aja"
        mood >= 20 -> "Sedih"
        else -> "Sangat sedih"
    }
}
