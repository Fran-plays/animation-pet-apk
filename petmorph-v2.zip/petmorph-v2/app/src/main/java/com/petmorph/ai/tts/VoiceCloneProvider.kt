package com.petmorph.ai.tts

import com.petmorph.ai.network.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

sealed class VoiceCloneResult {
    data class Success(val voiceId: String) : VoiceCloneResult()
    data class Error(val message: String) : VoiceCloneResult()
}

/** Voice cloning premium: sampel diupload ke backend -> voiceId untuk TTS. */
interface VoiceCloneProvider {
    suspend fun cloneSample(file: File): VoiceCloneResult
}

class BackendVoiceCloneProvider(private val api: ApiClient) : VoiceCloneProvider {
    override suspend fun cloneSample(file: File): VoiceCloneResult = withContext(Dispatchers.IO) {
        runCatching {
            val body = file.readBytes().toRequestBody("audio/*".toMediaType())
            val part = MultipartBody.Part.createFormData("sample", file.name, body)
            val res = api.api.cloneVoice(part)
            if (res.isSuccessful && res.body()?.voiceId != null) {
                VoiceCloneResult.Success(res.body()!!.voiceId)
            } else {
                VoiceCloneResult.Error(res.body()?.error ?: "Voice cloning gagal di server")
            }
        }.getOrElse { VoiceCloneResult.Error(it.message ?: "Network error") }
    }
}
