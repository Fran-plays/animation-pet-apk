package com.petmorph.ai.animation

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Paint
import android.graphics.Shader
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.petmorph.ai.data.model.Accessory
import com.petmorph.ai.data.model.Skin
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Renderer companion v2: bitmap dirender sebagai MESH yang benar-benar
 * dideformasikan (BitmapShader + android Canvas.drawVertices), plus skin,
 * aksesori, pseudo-blink, mulut saat bicara, dan partikel.
 */
@Composable
fun CompanionCanvas2(
    state: AnimationState,
    bitmap: Bitmap?,
    anchors: RigAnchors,
    talking: Boolean,
    blinkPhase: Float = 1f,
    mouthOpen: Float = 0f,
    skin: Skin = Skin.NONE,
    accessory: Accessory = Accessory.NONE,
    particles: Boolean = true,
    sizeDp: Dp = 220.dp,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    onDoubleClick: (() -> Unit)? = null,
    overlay: (@Composable BoxScope.() -> Unit)? = null,
) {
    if (bitmap == null) return

    val phase = remember { Animatable(0f) }
    LaunchedEffect(state) {
        val duration = when (state) {
            AnimationState.IDLE, AnimationState.SLEEP -> 2600
            AnimationState.SAD -> 3200
            AnimationState.DANCE -> 1400
            AnimationState.WAVE -> 1600
            AnimationState.ANGRY, AnimationState.EXCITED -> 1000
            else -> 1300
        }
        while (true) {
            phase.animateTo(1f, tween(duration))
            phase.snapTo(0f)
        }
    }

    val engine = remember { MeshWarpEngine() }
    val shaderPaint = remember(bitmap) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
    }
    val indices = remember(engine) { engine.triangleIndices() }

    val mesh = remember(bitmap) {
        val alpha = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(alpha, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        var minX = bitmap.width; var minY = bitmap.height; var maxX = -1; var maxY = -1
        for (y in 0 until bitmap.height) for (x in 0 until bitmap.width) {
            if ((alpha[y * bitmap.width + x] ushr 24) > 16) {
                if (x < minX) minX = x; if (x > maxX) maxX = x
                if (y < minY) minY = y; if (y > maxY) maxY = y
            }
        }
        if (maxX < minX) { minX = 0; minY = 0; maxX = bitmap.width - 1; maxY = bitmap.height - 1 }
        val n = engine.vertexCount()
        val texU = FloatArray(n); val texV = FloatArray(n)
        val gn = engine.gridN
        for (gy in 0 until gn) for (gx in 0 until gn) {
            val i = gy * gn + gx
            texU[i] = minX + (maxX - minX) * gx / (gn - 1f)
            texV[i] = minY + (maxY - minY) * gy / (gn - 1f)
        }
        MeshBuffers(texU, texV, FloatArray(n), FloatArray(n))
    }

    val ch = MeshCurves.channelsFor(state, phase.value)

    Box(
        modifier = modifier
            .size(sizeDp)
            .then(
                if (onClick != null || onDoubleClick != null) {
                    Modifier.pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { onClick?.invoke() },
                            onDoubleTap = { onDoubleClick?.invoke() },
                        )
                    }
                } else Modifier
            ),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val s = minOf(size.width / bitmap.width, size.height / bitmap.height)
            val dx = (size.width - bitmap.width * s) / 2f
            val dy = (size.height - bitmap.height * s) / 2f

            engine.computeWarp(anchors, ch, mesh.outX, mesh.outY, mesh.texU, mesh.texV,
                bitmap.width.toFloat(), bitmap.height.toFloat())
            val n = mesh.texU.size
            val verts = FloatArray(n * 2); val texs = FloatArray(n * 2)
            for (i in 0 until n) {
                verts[i * 2] = mesh.outX[i] * s + dx
                verts[i * 2 + 1] = mesh.outY[i] * s + dy
                texs[i * 2] = mesh.texU[i]
                texs[i * 2 + 1] = mesh.texV[i]
            }
            drawIntoCanvas { canvas ->
                canvas.androidCanvas.drawVertices(
                    android.graphics.Canvas.VertexMode.TRIANGLES,
                    n, verts, 0, texs, 0, null, 0,
                    indices, 0, indices.size, shaderPaint,
                )
            }

            skin.tintArgb?.let { drawCircle(Color(it), radius = size.minDimension / 2f, alpha = 0.45f) }
            skin.frameArgb?.let {
                drawCircle(Color(it), radius = size.minDimension / 2f - 4f, style = Stroke(width = 8f))
            }

            if (blinkPhase < 0.5f) {
                val ey = size.height * (0.10f + anchors.headY * 0.28f)
                drawLine(Color(0xFF2A1E28),
                    Offset(size.width * 0.32f, ey), Offset(size.width * 0.68f, ey), strokeWidth = 10f)
            }

            if (mouthOpen > 0.02f) {
                drawOval(Color(0xFF5B2333),
                    topLeft = Offset(size.width / 2f - 20f * mouthOpen, size.height * 0.72f - 12f * mouthOpen),
                    size = Size(40f * mouthOpen, 26f * mouthOpen))
            }

            val headSx = mesh.outX[engine.gridN * (engine.gridN / 2) + engine.gridN / 2] * s + dx
            val headSy = mesh.outY[engine.gridN * (engine.gridN / 2) + engine.gridN / 2] * s + dy
            when (accessory) {
                Accessory.BOW -> {
                    val bx = size.width * 0.72f; val by = size.height * 0.18f
                    drawCircle(Color(0xFFFF5C8A), 18f, Offset(bx - 14f, by))
                    drawCircle(Color(0xFFFF5C8A), 18f, Offset(bx + 14f, by))
                    drawCircle(Color(0xFFD63A6E), 10f, Offset(bx, by))
                }
                Accessory.PARTY_HAT -> {
                    val hx = headSx; val hy = headSy - size.height * 0.20f
                    val path = Path().apply {
                        moveTo(hx - 34f, hy + 40f); lineTo(hx, hy - 46f); lineTo(hx + 34f, hy + 40f); close()
                    }
                    drawPath(path, Color(0xFF6650a4))
                    drawCircle(Color(0xFFFFD166), 10f, Offset(hx, hy - 46f))
                }
                Accessory.CROWN -> {
                    val hx = headSx; val hy = headSy - size.height * 0.22f
                    val path = Path().apply {
                        moveTo(hx - 40f, hy + 30f); lineTo(hx - 40f, hy - 6f); lineTo(hx - 20f, hy + 10f)
                        lineTo(hx, hy - 20f); lineTo(hx + 20f, hy + 10f); lineTo(hx + 40f, hy - 6f)
                        lineTo(hx + 40f, hy + 30f); close()
                    }
                    drawPath(path, Color(0xFFFFC94D))
                }
                Accessory.NONE -> {}
            }

            if (particles && (state == AnimationState.HAPPY || state == AnimationState.EXCITED)) {
                repeat(6) { i ->
                    val ph = (phase.value * 2f * PI.toFloat() + i * 1.047f)
                    val r = size.minDimension * 0.42f
                    drawCircle(
                        Color(0xFFFFD166).copy(alpha = 0.5f + 0.3f * sin(ph + 1f)),
                        radius = 4f + 3f * sin(ph * 2f),
                        center = Offset(size.width / 2f + r * cos(ph), size.height / 2f + r * sin(ph)),
                    )
                }
            }
        }
        overlay?.invoke(this)
    }
}

private class MeshBuffers(
    val texU: FloatArray, val texV: FloatArray,
    val outX: FloatArray, val outY: FloatArray,
)
