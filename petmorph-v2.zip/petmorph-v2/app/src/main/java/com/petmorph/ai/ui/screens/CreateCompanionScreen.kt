package com.petmorph.ai.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.petmorph.ai.data.model.CompanionType
import com.petmorph.ai.data.model.Personality
import com.petmorph.ai.data.repository.BUILTIN_CHARACTERS
import com.petmorph.ai.navigation.Routes
import com.petmorph.ai.ui.CompanionViewModel
import com.petmorph.ai.ui.ProcessingState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateCompanionScreen(nav: NavController, vm: CompanionViewModel) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(CompanionType.CUTE_PET) }
    var personality by remember { mutableStateOf(Personality.CUTE) }
    var picked by remember { mutableStateOf<Uri?>(null) }
    var builtin by remember { mutableStateOf<Int?>(null) } // index BUILTIN_CHARACTERS
    val processing by vm.processing.collectAsState()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        picked = uri
        if (uri != null) builtin = null
    }

    LaunchedEffect(processing) {
        if (processing is ProcessingState.Success) {
            val id = (processing as ProcessingState.Success).companionId
            nav.navigate(Routes.setup(id)) { popUpTo(Routes.CREATE) { inclusive = true } }
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Create Companion") },
            navigationIcon = { IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
            .padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {

            OutlinedTextField(value = name, onValueChange = { name = it },
                label = { Text("Companion name") }, singleLine = true,
                modifier = Modifier.fillMaxWidth())

            Text("Companion type", style = MaterialTheme.typography.titleMedium)
            Column {
                CompanionType.entries.forEach { t ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = type == t, onClick = { type = t })
                        Text(t.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() })
                    }
                }
            }

            Text("Personality", style = MaterialTheme.typography.titleMedium)
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(personality.label)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    Personality.entries.forEach { p ->
                        DropdownMenuItem(text = { Text(p.label) }, onClick = { personality = p; expanded = false })
                    }
                }
            }

            // --- Karakter bawaan ---
            Text("Atau mulai dari karakter bawaan", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BUILTIN_CHARACTERS.forEachIndexed { i, bc ->
                    val bmp = remember(bc.asset) {
                        vm.loadBitmapFromResource(bc.asset)?.asImageBitmap()
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            builtin = if (builtin == i) null else i
                            if (builtin != null) picked = null
                        }) {
                        Surface(shape = RoundedCornerShape(16.dp),
                            color = if (builtin == i) MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant) {
                            Box(Modifier.size(72.dp).padding(6.dp)) {
                                bmp?.let {
                                    Image(bitmap = it, contentDescription = bc.defaultName,
                                        modifier = Modifier.fillMaxSize())
                                }
                            }
                        }
                        Text(bc.defaultName, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            // --- Upload gambar ---
            Text("Atau upload gambarmu sendiri", style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = { picker.launch("image/*") },
                modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(if (picked == null) "📷 Upload Image (PNG / JPG / WEBP)" else "Gambar terpilih ✓")
            }

            if (processing is ProcessingState.Error) {
                Text("⚠️ ${(processing as ProcessingState.Error).message}. Coba lagi.",
                    color = MaterialTheme.colorScheme.error)
            }

            when (processing) {
                ProcessingState.Loading -> Column(Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(); Spacer(Modifier.height(12.dp))
                    Text("Processing your character…")
                }
                else -> Button(
                    onClick = {
                        builtin?.let { i ->
                            val bc = BUILTIN_CHARACTERS[i]
                            vm.createFromAsset(bc.asset,
                                name.ifBlank { bc.defaultName }, type, personality)
                        } ?: picked?.let {
                            vm.createFromImage(it, name.ifBlank { "Companion" }, type, personality)
                        }
                    },
                    enabled = picked != null || builtin != null,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text("Create my companion!") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
