package com.petmorph.ai.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.petmorph.ai.tts.VoiceCloneState
import com.petmorph.ai.ui.CompanionViewModel

/** Premium: upload sampel suara -> jadi suara karakter. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceCloneScreen(nav: NavController, vm: CompanionViewModel, companionId: String) {
    val entity by vm.observeCompanion(companionId).collectAsState(initial = null)
    val cloneState by vm.voiceClone.collectAsState()
    val isPro by vm.container.subscription.isPro.collectAsState(initial = false)
    var sample by remember { mutableStateOf<Uri?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { sample = it }

    val e = entity ?: run {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Suara ${e.name}") },
            navigationIcon = { IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)) {

            if (!isPro) {
                Card(colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("⭐ Fitur Premium", style = MaterialTheme.typography.titleMedium)
                        Text("Unggah contoh suaramu dan ${e.name} akan menirukannya sebagai suara " +
                             "permanennya. Butuh langganan Pro.")
                    }
                }
            }

            Text("Suara saat ini: " + if (e.voiceId.isBlank())
                "Suara TTS bawaan (pitch %.1f)".format(e.voice().pitch)
            else "Suara clone ☁️ (${e.voiceId.take(8)}…)")

            OutlinedButton(onClick = { picker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(if (sample == null) "🎙️ Pilih contoh suara (MP3/M4A/WAV)" else "Contoh terpilih ✓ — pilih lagi")
            }

            when (val s = cloneState) {
                VoiceCloneState.Uploading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp)); Spacer(Modifier.width(10.dp))
                    Text("Menganalisis & meniru suaramu…")
                }
                is VoiceCloneState.Done -> Text("✅ Suara berhasil di-clone! ${e.name} sekarang bicara dengan suaramu.",
                    color = MaterialTheme.colorScheme.primary)
                is VoiceCloneState.Failed -> Text("⚠️ ${s.message}", color = MaterialTheme.colorScheme.error)
                VoiceCloneState.Idle -> {}
            }

            Button(onClick = { sample?.let { vm.cloneVoice(e, it) } },
                enabled = sample != null && isPro && cloneState != VoiceCloneState.Uploading,
                modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("Clone suara & pasang ke ${e.name}")
            }

            HorizontalDivider()
            Text("Tips: rekam 15–30 detik dengan jelas, tanpa musik latar, agar hasil mirip.",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}
