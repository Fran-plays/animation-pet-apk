package com.petmorph.ai.data.local

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.petmorph.ai.data.model.CompanionEntity
import com.petmorph.ai.data.model.ChatMessageEntity
import com.petmorph.ai.data.model.ReminderEntity

@Database(
    entities = [CompanionEntity::class, ChatMessageEntity::class, ReminderEntity::class],
    version = 2,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class CompanionDatabase : RoomDatabase() {
    abstract fun companionDao(): CompanionDao
    abstract fun chatDao(): ChatDao
    abstract fun reminderDao(): ReminderDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE companions ADD COLUMN xp INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE companions ADD COLUMN mood INTEGER NOT NULL DEFAULT 80")
                db.execSQL("ALTER TABLE companions ADD COLUMN traits TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE companions ADD COLUMN skin TEXT NOT NULL DEFAULT 'NONE'")
                db.execSQL("ALTER TABLE companions ADD COLUMN accessory TEXT NOT NULL DEFAULT 'NONE'")
                db.execSQL("ALTER TABLE companions ADD COLUMN voiceId TEXT NOT NULL DEFAULT ''")
                db.execSQL("CREATE TABLE IF NOT EXISTS chat_messages (id TEXT NOT NULL PRIMARY KEY, companionId TEXT NOT NULL, fromUser INTEGER NOT NULL, text TEXT NOT NULL, fromCloud INTEGER NOT NULL DEFAULT 0, timestamp INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS reminders (id TEXT NOT NULL PRIMARY KEY, companionId TEXT NOT NULL, hour INTEGER NOT NULL, minute INTEGER NOT NULL, message TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1)")
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_chat_companion ON chat_messages(companionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_reminder_companion ON reminders(companionId)")
            }
        }

        @Volatile private var instance: CompanionDatabase? = null
        fun get(context: Context): CompanionDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CompanionDatabase::class.java,
                    "petmorph.db"
                ).addMigrations(MIGRATION_1_2).build().also { instance = it }
            }
    }
}
