package com.petmorph.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.petmorph.ai.animation.*
import com.petmorph.ai.data.model.CompanionEntity
import com.petmorph.ai.domain.Gamification
import com.petmorph.ai.navigation.Routes
import com.petmorph.ai.overlay.FloatingCompanionService
import com.petmorph.ai.overlay.OverlayPermissionHelper
import com.petmorph.ai.ui.CompanionViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewScreen(nav: NavController, vm: CompanionViewModel, companionId: String) {
    val entity by vm.observeCompanion(companionId).collectAsState(initial = null)
    var anim by remember { mutableStateOf(AnimationState.IDLE) }
    var userForcedAnim by remember { mutableStateOf(false) }
    val talking by vm.talking.collectAsState()
    val chatMessages by vm.observeChat(companionId).collectAsState(initial = emptyList())
    var chatInput by remember { mutableStateOf("") }
    var showOverlayInfo by remember { mutableStateOf(false) }
    val isPro by vm.container.subscription.isPro.collectAsState(initial = false)

    // Idle companion memilih animasinya sendiri berdasarkan mood + watak
    LaunchedEffect(entity?.mood, entity?.traits) {
        if (!userForcedAnim) entity?.let { anim = Gamification.idleBias(it.mood, it.traitList()) }
    }

    val e = entity ?: run {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    val bitmap = remember(e.processedImagePath) { vm.loadBitmap(e.processedImagePath) }
    var anchors by remember { mutableStateOf(RigAnchors.DEFAULT) }
    LaunchedEffect(bitmap) { bitmap?.let { anchors = RigStore.anchorsFor(it) } }

    var blink by remember { mutableFloatStateOf(1f) }
    var mouth by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2600 + (0..1800).random().toLong())
            blink = 0.05f; delay(80); blink = 1f
        }
    }
    LaunchedEffect(talking) {
        while (true) {
            if (talking) { mouth = 0.5f + (0..40).random() / 100f; delay(90); mouth = 0.1f; delay(80) }
            else { if (mouth > 0f) mouth = 0f; delay(120) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(e.name) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                },
                actions = {
                    TextButton(onClick = { nav.navigate(Routes.customize(e.id)) }) { Text("Kostum") }
                    TextButton(onClick = { nav.navigate(Routes.voice(e.id)) }) { Text("Suara") }
                    TextButton(onClick = { nav.navigate(Routes.reminders(e.id)) }) { Text("Pengingat") }
                    TextButton(onClick = {
                        if (OverlayPermissionHelper.hasPermission(nav.context)) {
                            FloatingCompanionService.start(nav.context, e.id)
                        } else showOverlayInfo = true
                    }) { Text("Floating") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
                CompanionCanvas2(
                    state = anim, bitmap = bitmap, anchors = anchors, talking = talking,
                    blinkPhase = blink, mouthOpen = mouth,
                    skin = e.skinEnum(), accessory = e.accessoryEnum(), sizeDp = 200.dp,
                    onClick = {
                        anim = AnimationState.CLICK; userForcedAnim = true
                        vm.container.sounds.play(com.petmorph.ai.audio.SoundEffect.CLICK)
                        vm.onTap(e.id)
                    },
                    onDoubleClick = {
                        anim = AnimationState.EXCITED; userForcedAnim = true
                        vm.container.sounds.play(com.petmorph.ai.audio.SoundEffect.HAPPY)
                        vm.onTrick(e.id)
                    },
                )
                if (talking) {
                    SpeechBubble(Modifier.align(Alignment.TopEnd).padding(12.dp), "Bicara…")
                }
            }

            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("Lv.${Gamification.levelFor(e.xp)}", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        LinearProgressIndicator(progress = { Gamification.xpProgress(e.xp) },
                            modifier = Modifier.fillMaxWidth().height(6.dp))
                        Text("XP ${e.xp % Gamification.XP_PER_LEVEL}/${Gamification.XP_PER_LEVEL}",
                            style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        LinearProgressIndicator(progress = { e.mood / 100f },
                            modifier = Modifier.fillMaxWidth().height(6.dp),
                            color = if (e.mood < 30) MaterialTheme.colorScheme.error
                                    else MaterialTheme.colorScheme.primary)
                        Text(Gamification.moodLabel(e.mood), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(AnimationState.HAPPY, AnimationState.SLEEP, AnimationState.DANCE, AnimationState.JUMP)
                    .forEach { s ->
                        FilledTonalButton(onClick = { anim = s; userForcedAnim = true; vm.onTrick(e.id) }) {
                            Text(s.label)
                        }
                    }
            }
            HorizontalDivider(Modifier.padding(vertical = 4.dp))

            Text("  Chat dengan ${e.name}${if (isPro) "" else " (mode offline — Pro membuka cloud AI)"}",
                style = MaterialTheme.typography.labelLarge)
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(chatMessages, key = { it.id }) { m ->
                    Row(Modifier.fillMaxWidth(),
                        horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp,
                                bottomStart = if (m.fromUser) 16.dp else 4.dp,
                                bottomEnd = if (m.fromUser) 4.dp else 16.dp),
                            color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.widthIn(max = 300.dp),
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text(m.text)
                                if (!m.fromUser) Text(
                                    if (m.fromCloud) "☁️ cloud AI" else "📱 offline",
                                    style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = chatInput, onValueChange = { chatInput = it },
                    placeholder = { Text("Say something…") },
                    modifier = Modifier.weight(1f), maxLines = 2)
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val msg = chatInput.trim()
                    if (msg.isBlank()) return@Button
                    chatInput = ""
                    vm.chat(e, msg)
                }) { Text("Send") }
            }
        }
    }

    if (showOverlayInfo) {
        AlertDialog(
            onDismissRequest = { showOverlayInfo = false },
            title = { Text("Floating companion") },
            text = { Text(OverlayPermissionHelper.explainBeforeRequest()) },
            confirmButton = {
                TextButton(onClick = {
                    showOverlayInfo = false
                    OverlayPermissionHelper.requestPermission(nav.context as android.app.Activity)
                    nav.navigate(Routes.floatingControls(e.id))
                }) { Text("Izinkan") }
            },
            dismissButton = { TextButton(onClick = { showOverlayInfo = false }) { Text("Nanti") } },
        )
    }
}

@Composable
fun SpeechBubble(modifier: Modifier = Modifier, text: String) {
    Surface(modifier = modifier, shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.tertiaryContainer) {
        Text(text, Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium)
    }
}
