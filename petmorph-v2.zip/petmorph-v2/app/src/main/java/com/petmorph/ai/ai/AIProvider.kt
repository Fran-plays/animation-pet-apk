package com.petmorph.ai.ai

import com.petmorph.ai.data.model.Personality
import com.petmorph.ai.data.model.Trait
import com.petmorph.ai.network.ApiClient

sealed class ChatResult {
    data class Success(val reply: String, val fromCloud: Boolean) : ChatResult()
    data class Error(val message: String) : ChatResult()
}

data class ChatContext(
    val history: List<Pair<Boolean, String>> = emptyList(),
    val mood: Int = 80,
    val level: Int = 1,
    val traits: List<Trait> = emptyList(),
)

interface AIProvider {
    suspend fun chat(
        characterName: String,
        personality: Personality,
        userMessage: String,
        context: ChatContext = ChatContext(),
    ): ChatResult
}

class HybridAIProvider(
    private val api: ApiClient,
    @Suppress("unused") private val appContext: android.content.Context,
) : AIProvider {

    override suspend fun chat(
        characterName: String,
        personality: Personality,
        userMessage: String,
        context: ChatContext,
    ): ChatResult = try {
        val res = api.api.chat(
            com.petmorph.ai.network.ChatRequest(
                characterId = null, name = characterName,
                personality = personality.name, message = userMessage,
                history = context.history.map { com.petmorph.ai.network.HistoryMsg(it.first, it.second) },
                mood = context.mood, level = context.level,
                traits = context.traits.map { it.name },
            )
        )
        if (res.isSuccessful && res.body()?.reply != null) {
            ChatResult.Success(res.body()!!.reply, fromCloud = true)
        } else {
            ChatResult.Success(localReply(personality, userMessage, context), fromCloud = false)
        }
    } catch (e: Exception) {
        ChatResult.Success(localReply(personality, userMessage, context), fromCloud = false)
    }

    /** Responder offline: sadar personality, mood, level, watak, dan riwayat. */
    fun localReply(personality: Personality, message: String, ctx: ChatContext = ChatContext()): String {
        val m = message.lowercase()
        fun pick(vararg options: String) = options.random()
        val sad = ctx.mood < 30
        val hyper = ctx.mood > 85 && ctx.traits.contains(Trait.PLAYFUL)
        fun flavor(s: String): String = when {
            sad -> s.replace("!", "…")
            hyper -> "$s!!"
            else -> s
        }

        // Memori sederhana: mengulang pesan user sebelumnya bila diminta
        if (m.contains("ingat") && ctx.history.isNotEmpty()) {
            val lastUser = ctx.history.lastOrNull { it.first }?.second
            if (lastUser != null) {
                return flavor(pick(
                    "Tentu! Kamu tadi bilang soal itu — aku simpan baik-baik di memori kecilku.",
                    "Aku ingat kok! Kamu pernah cerita itu. Nggak akan kularungin.",
                ))
            }
        }

        val greet = when (personality) {
            Personality.CUTE -> pick("Hiii! *menggeliat bahagia*", "Halo halo! Kamu datang~")
            Personality.FUNNY -> pick("Yo! Ada guyonan baru hari ini?", "Hei hei! Siap-siap ketawa.")
            Personality.CALM -> pick("Halo. Tarik napas pelan dulu ya.", "Selamat datang kembali.")
            Personality.ENERGETIC -> pick("HALOOO! Aku sudah nungguin!", "Hei hei hei!! Ngapain kita hari ini?!")
            Personality.TSUNDERE -> pick("O-oh, kamu. Hmph, baru muncul sekarang.", "Hmph! Halo. Itu saja.")
            Personality.FRIENDLY -> pick("Hai! Gimana harimu?", "Halo! Senang kamu mampir.")
            Personality.CHAOTIC -> pick("GREETINGS!! Aku jadi unicorn hari ini.", "Halo! Kejutan apa hari ini?")
        }

        return flavor(when {
            m.contains("how are you") || m.contains("apa kabar") -> when (personality) {
                Personality.TSUNDERE -> pick("B-bagus saja! Bukan urusanmu kok!", "Hmph, baik. Jangan mikir aneh-aneh.")
                Personality.CHAOTIC -> pick("Aku sedang menari di awan pixel!", "Jadi naga hari ini, biasa.")
                else -> pick("Aku baik banget sekarang kamu di sini!", "Lumayan, tapi lebih baik lagi karena kamu!")
            }
            m.contains("siapa kamu") || m.contains("who are you") ->
                "Aku $characterName, companion-mu! Level ${ctx.level}, mood ${ctx.mood}/100."
            m.contains("level") || m.contains("mood") || m.contains("status") ->
                "Aku level ${ctx.level}, mood-ku ${if (ctx.mood >= 80) "sangat bahagia" else "oke"}. " +
                "Ajak aku ngobrol lagi biar naik level!"
            m.contains("hello") || m.contains("halo") || m.contains("hai") || m.contains("hi") -> greet
            m.contains("bye") || m.contains("dadah") || m.contains("sampai jumpa") ->
                pick("Dadah! Jangan lama-lama ya!", "Hati-hati! Aku tunggu di sini.")
            m.contains("terima kasih") || m.contains("makasih") || m.contains("thank") ->
                pick("Sama-sama!!", "Hehe, senang bisa membantu~")
            else -> pick(
                "Menarik juga! Ceritain lagi dong~",
                "Wah, aku catat ya di memori kecilku.",
                "Hmm, coba jelasin lebih detail?",
            )
        })
    }
}
