package com.petmorph.ai.data.repository

import android.content.Context
import android.graphics.BitmapFactory
import androidx.annotation.DrawableRes
import com.petmorph.ai.R
import com.petmorph.ai.data.local.CompanionDao
import com.petmorph.ai.data.model.*
import com.petmorph.ai.storage.StorageProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class CompanionRepository(
    private val dao: CompanionDao,
    private val context: Context,
) {
    fun observeCompanions(): Flow<List<CompanionEntity>> = dao.observeAll()
    fun observeCompanion(id: String): Flow<CompanionEntity?> = dao.observeById(id)

    suspend fun get(id: String): CompanionEntity? = dao.getById(id)
    suspend fun count(): Int = dao.count()
    suspend fun save(entity: CompanionEntity) = dao.insert(entity)
    suspend fun update(entity: CompanionEntity) = dao.update(entity)

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        dao.getById(id)?.let { entity ->
            dao.delete(entity)
            File(entity.originalImagePath).delete()
            File(entity.processedImagePath).delete()
        }
    }

    suspend fun duplicate(id: String): CompanionEntity? = withContext(Dispatchers.IO) {
        val src = dao.getById(id) ?: return@withContext null
        val newId = UUID.randomUUID().toString()
        val copy = src.copy(
            id = newId, name = src.name + " copy",
            originalImagePath = copyFile(src.originalImagePath, "original_$newId.png"),
            processedImagePath = copyFile(src.processedImagePath, "processed_$newId.png"),
            isDemo = false,
        )
        dao.insert(copy)
        copy
    }

    private fun copyFile(path: String, name: String): String {
        val dst = File(context.filesDir, name)
        runCatching { File(path).copyTo(dst, overwrite = true) }
        return dst.absolutePath
    }

    /** Buat companion langsung dari aset karakter bawaan (tanpa upload). */
    suspend fun createFromAsset(
        @DrawableRes asset: Int,
        name: String,
        type: CompanionType,
        personality: Personality,
        storage: StorageProvider,
    ): CompanionEntity = withContext(Dispatchers.IO) {
        val bmp = BitmapFactory.decodeResource(context.resources, asset)
            ?: throw IllegalStateException("Asset karakter tidak ditemukan")
        val id = UUID.randomUUID().toString()
        val entity = CompanionEntity(
            id = id, name = name, type = type, personality = personality,
            originalImagePath = storage.saveBitmap(bmp, "original_$id.png"),
            processedImagePath = storage.saveBitmap(bmp, "processed_$id.png"),
            voiceJson = CompanionEntity.voiceToJson(VoiceConfig()),
        )
        dao.insert(entity)
        entity
    }

    suspend fun seedDemoIfNeeded(storage: StorageProvider) = withContext(Dispatchers.IO) {
        if (dao.count() > 0) return@withContext
        val bmp = BitmapFactory.decodeResource(context.resources, R.drawable.mochi_demo)
            ?: return@withContext
        dao.insert(
            CompanionEntity(
                name = "Mochi", type = CompanionType.CUTE_PET,
                personality = Personality.ENERGETIC,
                originalImagePath = storage.saveBitmap(bmp, "original_demo_mochi.png"),
                processedImagePath = storage.saveBitmap(bmp, "processed_demo_mochi.png"),
                voiceJson = CompanionEntity.voiceToJson(VoiceConfig(pitch = 1.35f)),
                isDemo = true,
            )
        )
    }
}

data class BuiltinCharacter(
    @DrawableRes val asset: Int, val defaultName: String,
    val type: CompanionType, val personality: Personality,
)

val BUILTIN_CHARACTERS = listOf(
    BuiltinCharacter(R.drawable.mochi_demo, "Mochi", CompanionType.CUTE_PET, Personality.ENERGETIC),
    BuiltinCharacter(R.drawable.kiki_cat, "Kiki", CompanionType.CUTE_PET, Personality.TSUNDERE),
    BuiltinCharacter(R.drawable.bolt_robot, "Bolt", CompanionType.VTUBER_MINI, Personality.FUNNY),
    BuiltinCharacter(R.drawable.momo_ghost, "Momo", CompanionType.ANIME_CHARACTER, Personality.CALM),
)
