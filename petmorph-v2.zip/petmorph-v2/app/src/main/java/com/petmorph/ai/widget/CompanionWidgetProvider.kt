package com.petmorph.ai.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.widget.RemoteViews
import com.petmorph.ai.MainActivity
import com.petmorph.ai.R
import com.petmorph.ai.domain.Gamification
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/** Widget home screen: foto companion + level + mood; tap membuka app. */
class CompanionWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
    ) {
        val app = context.applicationContext as com.petmorph.ai.PetMorphApp
        val latest = runBlocking { app.container.repository.observeCompanions().first().firstOrNull() }
        appWidgetIds.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_companion)
            latest?.let { c ->
                runCatching { BitmapFactory.decodeFile(c.processedImagePath) }.getOrNull()
                    ?.let { views.setImageViewBitmap(R.id.widget_image, it) }
                views.setTextViewText(R.id.widget_name, c.name)
                views.setTextViewText(R.id.widget_status,
                    "Lv.${Gamification.levelFor(c.xp)} · ${Gamification.moodLabel(c.mood)}")
            } ?: run {
                views.setTextViewText(R.id.widget_name, "PetMorph")
                views.setTextViewText(R.id.widget_status, "Buat companion-mu!")
            }
            views.setOnClickPendingIntent(R.id.widget_root, PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            appWidgetManager.updateAppWidget(id, views)
        }
    }

    companion object {
        fun notifyChanged(context: Context) {
            context.sendBroadcast(
                Intent(context, CompanionWidgetProvider::class.java)
                    .setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE))
        }
    }
}
