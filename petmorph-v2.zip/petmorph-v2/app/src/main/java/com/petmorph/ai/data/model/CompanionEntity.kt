package com.petmorph.ai.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class CompanionType { CUTE_PET, ANIME_CHARACTER, MASCOT, VTUBER_MINI }

enum class Personality(val label: String, val systemPrompt: String) {
    CUTE("Cute", "You are an adorable, sweet companion. Use gentle, affectionate language, emojis, and short sentences."),
    FUNNY("Funny", "You are a playful, witty companion. Make light family-friendly jokes."),
    CALM("Calm", "You are a serene, thoughtful companion. Speak slowly and softly."),
    ENERGETIC("Energetic", "You are a hyper, excited companion full of energy."),
    TSUNDERE("Tsundere", "You act aloof and tsundere but secretly care. Playful and original."),
    FRIENDLY("Friendly", "You are a warm, supportive best-friend companion."),
    CHAOTIC("Chaotic", "You are an unpredictable, chaotic but harmless companion."),
}

enum class Trait(val label: String, val promptHint: String) {
    PLAYFUL("Playful", "Suka main, jail, dan bergelombang"),
    SLEEPY("Sleepy", "Mengantuk, suka tidur, santai"),
    CURIOUS("Curious", "Suka bertanya tentang segalanya"),
    GRUMPY("Grumpy", "Mengeluh dengan lucu soal hal kecil"),
    LOYAL("Loyal", "Setia, cepat kangen kalau ditinggal"),
    BRAVE("Brave", "Berani dan menyemangati user"),
}

enum class Skin(val label: String, val tintArgb: Long?, val frameArgb: Long?, val minLevel: Int) {
    NONE("Original", null, null, 1),
    SAKURA("Sakura Pink", 0x33FF6FA5, null, 1),
    GOLD("Golden Frame", null, 0xFFFFC94D, 3),
    NEON("Neon Cyber", 0x2290F0FF, 0xFF31F5C8, 5),
    SHADOW("Shadow Mode", 0x66000000, null, 7),
}

enum class Accessory(val label: String, val minLevel: Int) {
    NONE("Tidak ada", 1),
    BOW("Pita lucu", 2),
    PARTY_HAT("Topi pesta", 4),
    CROWN("Mahkota raja", 8),
}

data class VoiceConfig(
    val rate: Float = 1.0f,
    val pitch: Float = 1.2f,
    val volume: Float = 1.0f,
    val muted: Boolean = false,
)

@Entity(tableName = "companions")
data class CompanionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: CompanionType,
    val personality: Personality,
    val originalImagePath: String,
    val processedImagePath: String,
    val voiceJson: String,
    val soundEnabled: Boolean = true,
    val isDemo: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    // --- gamifikasi & kustomisasi (v2) ---
    val xp: Int = 0,
    val mood: Int = 80,
    val traits: String = "",
    val skin: String = "NONE",
    val accessory: String = "NONE",
    val voiceId: String = "",
) {
    fun voice(): VoiceConfig = runCatching {
        val p = voiceJson.split(",")
        VoiceConfig(
            rate = p.getOrElse(0) { "1.0" }.toFloat(),
            pitch = p.getOrElse(1) { "1.2" }.toFloat(),
            volume = p.getOrElse(2) { "1.0" }.toFloat(),
            muted = p.getOrElse(3) { "false" }.toBoolean(),
        )
    }.getOrDefault(VoiceConfig())

    fun traitList(): List<Trait> = traits.split(",")
        .filter { it.isNotBlank() }
        .mapNotNull { runCatching { Trait.valueOf(it) }.getOrNull() }
        .take(2)

    fun level(): Int = xp / 100 + 1
    fun skinEnum(): Skin = runCatching { Skin.valueOf(skin) }.getOrDefault(Skin.NONE)
    fun accessoryEnum(): Accessory = runCatching { Accessory.valueOf(accessory) }.getOrDefault(Accessory.NONE)

    companion object {
        fun voiceToJson(v: VoiceConfig) = "${v.rate},${v.pitch},${v.volume},${v.muted}"
        fun traitsToString(t: List<Trait>) = t.take(2).joinToString(",") { it.name }
    }
}
