package com.petmorph.ai.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.petmorph.ai.data.model.ReminderEntity
import com.petmorph.ai.ui.CompanionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemindersScreen(nav: NavController, vm: CompanionViewModel, companionId: String) {
    val entity by vm.observeCompanion(companionId).collectAsState(initial = null)
    val reminders by vm.observeReminders(companionId).collectAsState(initial = emptyList())
    var showAdd by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var hour by remember { mutableIntStateOf(19) }
    var minute by remember { mutableIntStateOf(0) }

    val e = entity ?: run {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Pengingat ${e.name}") },
            navigationIcon = { IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("${e.name} akan mengingatkanmu lewat notifikasi setiap hari di jam yang kamu tentukan.",
                style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(reminders, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("%02d:%02d".format(r.hour, r.minute),
                                    style = MaterialTheme.typography.titleMedium)
                                Text(r.message)
                            }
                            TextButton(onClick = { vm.removeReminder(r) }) { Text("Hapus") }
                        }
                    }
                }
            }
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
                Text("+ Tambah pengingat")
            }
        }
    }

    if (showAdd) {
        AlertDialog(onDismissRequest = { showAdd = false },
            title = { Text("Pengingat baru") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = message, onValueChange = { message = it },
                        label = { Text("Pesan pengingat") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Jam"); Spacer(Modifier.width(8.dp))
                        Slider(value = hour.toFloat(), onValueChange = { hour = it.toInt() },
                            valueRange = 0f..23f, modifier = Modifier.weight(1f))
                        Text("%02d".format(hour))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Menit"); Spacer(Modifier.width(8.dp))
                        Slider(value = minute.toFloat(), onValueChange = { minute = it.toInt() },
                            valueRange = 0f..59f, steps = 58, modifier = Modifier.weight(1f))
                        Text("%02d".format(minute))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (message.isNotBlank()) {
                        vm.addReminder(companionId, hour, minute, message.trim())
                        showAdd = false; message = ""
                    }
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Batal") } })
    }
}
