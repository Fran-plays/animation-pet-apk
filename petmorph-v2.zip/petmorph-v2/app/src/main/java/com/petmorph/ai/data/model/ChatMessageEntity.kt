package com.petmorph.ai.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val companionId: String,
    val fromUser: Boolean,
    val text: String,
    val fromCloud: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val companionId: String,
    val hour: Int,
    val minute: Int,
    val message: String,
    val enabled: Boolean = true,
)
