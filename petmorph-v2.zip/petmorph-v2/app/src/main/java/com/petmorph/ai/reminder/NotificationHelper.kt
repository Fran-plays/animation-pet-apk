package com.petmorph.ai.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat
import com.petmorph.ai.MainActivity
import com.petmorph.ai.R

object NotificationHelper {
    const val CHANNEL_REMINDERS = "companion_reminders"

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_REMINDERS, "Companion reminders",
                NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun showReminder(context: Context, companionName: String, message: String, imagePath: String?) {
        ensureChannel(context)
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val bmp = imagePath?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
        val notif = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_stat_pet)
            .setContentTitle("$companionName mengingatkanmu")
            .setContentText(message)
            .setLargeIcon(bmp)
            .setStyle(bmp?.let { NotificationCompat.BigPictureStyle().bigPicture(it) })
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(message.hashCode(), notif)
    }
}
