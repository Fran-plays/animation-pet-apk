package com.petmorph.ai.animation

/** Anchor otomatis dari alpha mask; ter-normalisasi 0..1 thd bbox alpha. Pure Kotlin. */
data class RigAnchors(
    val headX: Float, val headY: Float,
    val bodyX: Float, val bodyY: Float,
    val leftX: Float, val rightX: Float,
) {
    companion object {
        val DEFAULT = RigAnchors(0.5f, 0.28f, 0.5f, 0.62f, 0.08f, 0.92f)
    }
}

class AutoRigger {
    fun rig(width: Int, height: Int, pixels: IntArray): RigAnchors {
        var minX = width; var minY = height; var maxX = -1; var maxY = -1
        for (y in 0 until height) for (x in 0 until width) {
            if ((pixels[y * width + x] ushr 24) > 16) {
                if (x < minX) minX = x; if (x > maxX) maxX = x
                if (y < minY) minY = y; if (y > maxY) maxY = y
            }
        }
        if (maxX < minX || maxY < minY) return RigAnchors.DEFAULT
        val bw = (maxX - minX + 1).toFloat()
        val bh = (maxY - minY + 1).toFloat()

        fun centroid(yFrom: Int, yTo: Int): Pair<Float, Float>? {
            var sx = 0.0; var sy = 0.0; var n = 0
            for (y in yFrom.coerceIn(0, height - 1)..yTo.coerceIn(0, height - 1))
                for (x in minX..maxX)
                    if ((pixels[y * width + x] ushr 24) > 16) { sx += x; sy += y; n++ }
            if (n == 0) return null
            return ((sx / n).toFloat() - minX) / bw to ((sy / n).toFloat() - minY) / bh
        }

        val head = centroid(minY, (minY + bh * 0.38f).toInt()) ?: (0.5f to 0.25f)
        val body = centroid((minY + bh * 0.45f).toInt(), (minY + bh * 0.75f).toInt()) ?: (0.5f to 0.6f)
        return RigAnchors(head.first, head.second, body.first, body.second, 0.06f, 0.94f)
    }
}
