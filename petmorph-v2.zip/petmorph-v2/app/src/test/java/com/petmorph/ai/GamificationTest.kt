package com.petmorph.ai

import com.petmorph.ai.animation.AnimationState
import com.petmorph.ai.data.model.Trait
import com.petmorph.ai.domain.Gamification
import org.junit.Assert.*
import org.junit.Test

class GamificationTest {
    @Test
    fun `level scales with xp`() {
        assertEquals(1, Gamification.levelFor(0))
        assertEquals(2, Gamification.levelFor(100))
        assertEquals(5, Gamification.levelFor(450))
    }

    @Test
    fun `mood is clamped and traits modify decay`() {
        assertEquals(0, (0 + (-5)).coerceIn(Gamification.MIN_MOOD, Gamification.MAX_MOOD))
        assertTrue(Gamification.moodDecayPerHour(listOf(Trait.LOYAL)) >
                   Gamification.moodDecayPerHour(listOf(Trait.SLEEPY)))
    }

    @Test
    fun `idle bias reacts to mood and traits`() {
        assertEquals(AnimationState.SAD, Gamification.idleBias(10, emptyList()))
        assertEquals(AnimationState.SLEEP, Gamification.idleBias(40, listOf(Trait.SLEEPY)))
        assertEquals(AnimationState.EXCITED, Gamification.idleBias(95, emptyList()))
        assertEquals(AnimationState.IDLE, Gamification.idleBias(60, emptyList()))
    }
}
