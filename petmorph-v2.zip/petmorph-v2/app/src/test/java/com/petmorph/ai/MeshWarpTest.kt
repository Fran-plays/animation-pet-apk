package com.petmorph.ai

import com.petmorph.ai.animation.*
import org.junit.Assert.*
import org.junit.Test

class MeshWarpTest {
    private val engine = MeshWarpEngine(gridN = 8)

    @Test
    fun `warp output stays finite for every animation state`() {
        val anchors = RigAnchors.DEFAULT
        val n = engine.vertexCount()
        val texU = FloatArray(n) { (it % 8) * 10f }
        val texV = FloatArray(n) { (it / 8) * 10f }
        val outX = FloatArray(n); val outY = FloatArray(n)
        AnimationState.entries.forEach { state ->
            for (phase in listOf(0f, 0.25f, 0.5f, 0.75f)) {
                engine.computeWarp(anchors, MeshCurves.channelsFor(state, phase),
                    outX, outY, texU, texV, 70f, 70f)
                outX.forEach { assertTrue(it.isFinite()) }
                outY.forEach { assertTrue(it.isFinite()) }
            }
        }
    }

    @Test
    fun `idle warp barely moves corner vertices`() {
        val n = engine.vertexCount()
        val texU = FloatArray(n) { (it % 8) * 10f }
        val texV = FloatArray(n) { (it / 8) * 10f }
        val outX = FloatArray(n); val outY = FloatArray(n)
        engine.computeWarp(RigAnchors.DEFAULT, MeshChannels(),
            outX, outY, texU, texV, 70f, 70f)
        assertEquals(texU[0], outX[0], 0.001f) // pojok kiri-atas tanpa channel = diam
    }

    @Test
    fun `auto rigger finds head above body on a blob`() {
        // Blob: lingkaran di tengah atas (kepala) + tubuh di bawah
        val w = 64; val h = 64
        val px = IntArray(w * h)
        for (y in 8..28) for (x in 24..40) px[y * w + x] = -0x1000000 // kepala
        for (y in 28..56) for (x in 16..48) px[y * w + x] = -0x1000000 // tubuh
        val anchors = AutoRigger().rig(w, h, px)
        assertTrue(anchors.headY < anchors.bodyY)
        assertEquals(0.5f, anchors.headX, 0.2f)
    }
}
