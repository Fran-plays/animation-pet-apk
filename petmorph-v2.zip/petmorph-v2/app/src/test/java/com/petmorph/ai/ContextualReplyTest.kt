package com.petmorph.ai

import com.petmorph.ai.ai.ChatContext
import com.petmorph.ai.ai.HybridAIProvider
import com.petmorph.ai.data.model.Personality
import com.petmorph.ai.data.model.Trait
import org.junit.Assert.*
import org.junit.Test

class ContextualReplyTest {
    private val r = HybridAIProvider(com.petmorph.ai.network.ApiClient("http://localhost/"), null)

    @Test
    fun `companion remembers previous user message when asked`() {
        val ctx = ChatContext(history = listOf(true to "aku suka ramen"), mood = 80, level = 2)
        val reply = r.localReply(Personality.FRIENDLY, "kamu ingat aku suka apa?", ctx)
        assertTrue(reply.contains("ramen"))
    }

    @Test
    fun `status reply includes level and mood`() {
        val reply = r.localReply(Personality.CUTE, "status kamu?", ChatContext(mood = 70, level = 4))
        assertTrue(reply.contains("4") && reply.contains("70"))
    }

    @Test
    fun `sad mood softens punctuation`() {
        val happy = r.localReply(Personality.ENERGETIC, "halo", ChatContext(mood = 90))
        val sad = r.localReply(Personality.ENERGETIC, "halo", ChatContext(mood = 10))
        assertNotEquals(happy, sad)
    }
}
