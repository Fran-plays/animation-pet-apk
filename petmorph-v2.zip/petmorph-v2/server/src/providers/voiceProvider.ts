import { createHash } from "crypto";
import { config } from "../config";

export interface VoiceCloneProvider {
  clone(input: Buffer, fileName: string): Promise<string>; // returns voiceId
}

/** ElevenLabs-compatible voice cloning. */
export class ElevenLabsVoiceCloneProvider implements VoiceCloneProvider {
  async clone(input: Buffer, fileName: string): Promise<string> {
    const form = new FormData();
    form.append("name", "petmorph-clone-" + Date.now());
    form.append("files", new Blob([new Uint8Array(input)]), fileName);
    const res = await fetch("https://api.elevenlabs.io/v1/voices/add", {
      method: "POST",
      headers: { "xi-api-key": config.tts.apiKey },
      body: form,
    });
    if (!res.ok) throw new Error(`voice clone error: ${res.status}`);
    const data = (await res.json()) as { voice_id?: string };
    if (!data.voice_id) throw new Error("voice clone returned no voice_id");
    return data.voice_id;
  }
}

/** Offline fallback: hash deterministik — aplikasi tetap jalan tanpa key. */
export class MockVoiceCloneProvider implements VoiceCloneProvider {
  async clone(input: Buffer): Promise<string> {
    return "mock-voice-" + createHash("sha1").update(input).digest("hex").slice(0, 12);
  }
}

export function createVoiceCloneProvider(): VoiceCloneProvider {
  return config.tts.provider === "cloud" && config.tts.apiKey
    ? new ElevenLabsVoiceCloneProvider()
    : new MockVoiceCloneProvider();
}
