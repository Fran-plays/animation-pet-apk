import express from "express";
import helmet from "helmet";
import cors from "cors";
import path from "path";
import { config } from "./config";
import { logger } from "./utils/logger";
import router from "./routes";
import { errorHandler, notFound } from "./middleware/errorHandler";

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use("/storage", express.static(path.resolve(config.storage.url)));
app.use("/api", router);
app.use(notFound);
app.use(errorHandler);

app.listen(config.port, () => {
  logger.info(`PetMorph server listening on :${config.port} (${config.env})`);
});

export default app;
