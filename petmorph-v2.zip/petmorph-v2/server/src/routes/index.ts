import { Router } from "express";
import rateLimit from "express-rate-limit";
import * as characters from "../controllers/charactersController";
import * as ai from "../controllers/aiController";
import * as health from "../controllers/healthController";
import { optionalAuth, requireAuth } from "../middleware/auth";
import { upload } from "../middleware/upload";
import { apiLimiter, aiLimiter, uploadLimiter } from "../middleware/rateLimit";
import { createImageProcessor } from "../providers/imageProcessor";
import { HttpError } from "../middleware/errorHandler";
import { createVoiceCloneProvider } from "../providers/voiceProvider";
import multer from "multer";

const router = Router();
const imageProcessor = createImageProcessor();

router.use(apiLimiter);

router.get("/health", health.health);

router.get("/characters", optionalAuth, characters.listCharacters);
router.post("/characters/create", optionalAuth, uploadLimiter, upload.single("image"), characters.createCharacter);
router.get("/characters/:id", optionalAuth, characters.getCharacter);
router.delete("/characters/:id/delete", optionalAuth, requireAuth, characters.deleteCharacter);

const voiceCloner = createVoiceCloneProvider();
const audioUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ok = ["audio/mpeg", "audio/mp4", "audio/wav", "audio/x-m4a", "audio/webm", "audio/ogg"]
      .includes(file.mimetype);
    cb(ok ? null : new HttpError(415, `unsupported audio type: ${file.mimetype}`), ok);
  },
});

router.post("/voice/clone", uploadLimiter, audioUpload.single("sample"), async (req, res, next) => {
  try {
    if (!req.file) throw new HttpError(400, "audio sample is required");
    const head = req.file.buffer.subarray(0, 12);
    const looksAudio = head[0] === 0xff || head.subarray(0, 4).toString() === "RIFF"
      || head.subarray(4, 8).toString() === "ftyp" || head.subarray(0, 4).toString() === "OggS";
    if (!looksAudio) throw new HttpError(415, "file content does not look like audio");
    const voiceId = await voiceCloner.clone(req.file.buffer, req.file.originalname);
    res.json({ voiceId });
  } catch (e) { next(e); }
});

router.post("/ai/chat", aiLimiter, ai.chat);
router.post("/tts", aiLimiter, ai.ttsHandler);

// JSON variant of image processing (Android app uses local pipeline by default)
router.post("/image/process", uploadLimiter, upload.single("image"), async (req, res, next) => {
  try {
    if (!req.file) throw new HttpError(400, "image file is required");
    const out = await imageProcessor.process(req.file.buffer);
    res.json({ imageBase64: out.toString("base64") });
  } catch (e) { next(e); }
});

export default router;
