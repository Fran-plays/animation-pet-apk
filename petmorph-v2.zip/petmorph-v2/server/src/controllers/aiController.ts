import { Request, Response } from "express";
import { createAIProvider } from "../providers/aiProvider";
import { createTTSProvider } from "../providers/ttsProvider";
import { chatSchema, ttsSchema, PERSONALITY_PROMPTS } from "../models/character";

const ai = createAIProvider();
const tts = createTTSProvider();

export async function chat(req: Request, res: Response) {
  const data = chatSchema.parse(req.body);
  const moodLine =
    data.mood < 30 ? "You feel very sad and lonely right now; be gentle and a bit clingy."
    : data.mood > 85 ? "You are extremely happy and energetic right now."
    : "You are in a normal, content mood.";
  const traitLine = data.traits.length
    ? `Your traits: ${data.traits.join(", ")} — let them color your speech.`
    : "";
  const systemPrompt =
    (PERSONALITY_PROMPTS[data.personality.toLowerCase()] ?? PERSONALITY_PROMPTS.friendly) +
    ` You are ${data.name}, level ${data.level}. ${moodLine} ${traitLine}` +
    ` Reply in ${data.language === "auto" ? "the user's language" : data.language}.` +
    ` Keep answers under ${data.maxLength} characters. Never break character.` +
    ` Use the conversation history for context and remember what the user told you.`;

  const historyMessages = data.history.slice(-10).map((h) => ({
    role: h.fromUser ? ("user" as const) : ("assistant" as const),
    content: h.text,
  }));

  // Mock provider tidak menerima history — hanya digunakan untuk LLM sungguhan
  const provider: any = ai;
  const reply = provider.chatWithHistory
    ? await provider.chatWithHistory({
        systemPrompt, name: data.name, message: data.message,
        maxLength: data.maxLength, language: data.language, history: historyMessages,
      })
    : await ai.chat({
        systemPrompt, name: data.name, message: data.message,
        maxLength: data.maxLength, language: data.language,
      });
  res.json({ reply });
}

export async function ttsHandler(req: Request, res: Response) {
  const data = ttsSchema.parse(req.body);
  const audio = await tts.synthesize(data.text, data.voice);
  res.setHeader("Content-Type", "audio/wav");
  res.send(audio);
}
