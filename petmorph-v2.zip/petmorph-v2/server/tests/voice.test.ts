import { MockVoiceCloneProvider } from "../src/providers/voiceProvider";

describe("voice clone provider", () => {
  it("mock clone returns a deterministic voice id", async () => {
    const p = new MockVoiceCloneProvider();
    const a = await p.clone(Buffer.from("fake-audio-bytes-1"), "s.m4a");
    const b = await p.clone(Buffer.from("fake-audio-bytes-1"), "s.m4a");
    const c = await p.clone(Buffer.from("fake-audio-bytes-2"), "s.m4a");
    expect(a).toMatch(/^mock-voice-[0-9a-f]{12}$/);
    expect(a).toBe(b);
    expect(a).not.toBe(c);
  });
});
